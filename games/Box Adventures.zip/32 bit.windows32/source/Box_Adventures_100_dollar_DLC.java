import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Box_Adventures_100_dollar_DLC extends PApplet {

//jumping collision and multiple box collision helped by https://happycoding.io/tutorials/processing/collision-detection#edge-collision-detection
//thanks trevor
//follow griffin @ twitch.tv/flufferduff
//follow phillip @ twitch.tv/king_hexagon  
//ooga booga
//general variables
float squareSize=50;
int black = color(0,0,0);
int green = color(0,255,0);
int red = color(255,0,0);
int magenta = color(225,0,255);
int cyan = color(0,255,255);
boolean gameRunning;
PFont silkscreen;
//player variables
float playerX; 
float playerY;
float playerwidth=50;
float playerheight=50;
float playerSpeed=5;
float realplayerSpeed=5;
int deaths=0;
//key variables
float left;
float right;
boolean leftPressed;
boolean rightPressed;
boolean shiftPressed;
boolean upPressed;
boolean spacePressed;
//gravity variables
float gravity=.1f;
float jumpPower=5;
float jumpSpeed;
float realgravity=.1f;
float realjumpPower=5;
//collision variables
boolean leftCollide;
boolean rightCollide;
boolean groundCollide;
boolean ceilingCollide;
boolean jumping;
boolean overGround;
//ground variables
float groundX=200;
float groundY=400;
float groundwidth=50;
float groundheight=50;
Ground ground = new Ground(groundX,groundY,groundwidth,groundheight,black);
ArrayList<Ground> groundtiles = new ArrayList<Ground>();
//hazard variables
float hazardX=0;
float hazardY=500;
float hazardwidth=50;
float hazardheight=50;
boolean hazardTouch;
Hazard hazard = new Hazard(hazardX,hazardY,hazardwidth,hazardheight,red);
ArrayList<Hazard> hazardtiles = new ArrayList<Hazard>();
//dash variable
boolean hasDashed;
boolean dashing;
boolean dashleft;
boolean dashright;
float dashLength=400;
float dashDistance=0;
float dashSpeed=10;
//reset variables
boolean resetP;
//level variables
float levelstartpos[] = new float [2];
int levelnumber;
boolean newlevel;
//goal Variables
float goalX;
float goalY;
float goalwidth=50;
float goalheight=50;
boolean goalTouch;
Goal goal = new Goal(goalX,goalY,goalwidth,goalheight,green);
//extra jump variables
float jumpX;
float jumpY;
float jumpwidth=50;
float jumpheight=50;
boolean jumpTouch;
Jump jump = new Jump(jumpX,jumpY,jumpwidth,jumpheight,cyan);
ArrayList<Jump> jumptiles = new ArrayList<Jump>();

//titlescreen variables
String[] flavortext;
String flavor;
int titlepage=0;
boolean titleScreen=true;
float gameStarttime;
int gametime;
String seconds;
String minutes;
String hours;
String time;

//endscreen variables
boolean endScreen=false;
public void setup()
{
  
  background(255);
  levelnumber=1;
  newlevel=true;
  gameRunning=false;
  silkscreen=createFont("slkscr.ttf",12);
  randomFlavor();
}
public void draw()
{
  if(gameRunning)
  {
    if(newlevel==true)
    {
    level(levelnumber);
    playerX=levelstartpos[0];
    playerY=levelstartpos[1];
    println("new level");
    println("level "+levelnumber);
    }
   moveSquare();
   gravity();
   goalCollision(playerX,playerY,playerwidth,playerheight,goal.x,goal.y,goal.xwidth,goal.yheight);
   for(int i=0;i<groundtiles.size();i++)
   {
   Ground tile = groundtiles.get(i);
   groundCollision(playerX,playerY,playerwidth,playerheight,tile.x,tile.y,tile.xwidth,tile.yheight);
   }
   for(int i=0;i<hazardtiles.size();i++)
   {
   Hazard tile = hazardtiles.get(i);
   hazardCollision(playerX,playerY,playerwidth,playerheight,tile.x,tile.y,tile.xwidth,tile.yheight);
   }
   for(int i=0;i<jumptiles.size();i++)
   {
   Jump tile = jumptiles.get(i);
   extraJumpCollision(playerX,playerY,playerwidth,playerheight,tile.x,tile.y,tile.xwidth,tile.yheight);
   if(jumpTouch){jumptiles.remove(i);hasDashed=false;jumping=false;jumpTouch=false;} 
   }
   drawLevel(); 
   drawPlayer(playerX,playerY,playerwidth,playerheight); 
   playerReset();
  }
  else if(titleScreen)
  {
   if(spacePressed&&(titlepage==0)){gameRunning=true;titleScreen=false;}
   else if(leftPressed&&(titlepage>-1)){titlepage--;leftPressed=false;}
   else if(rightPressed&&(titlepage<1)){titlepage++;rightPressed=false;}
   drawTitle();
   gameStarttime=millis();
  }
  else if(endScreen)
  {
  background(255);
  textAlign(CENTER);
  textFont(silkscreen,100);
  fill(0);
  text("You Win",width/2,200);
  textFont(silkscreen,50);
  text("You beat the game in",width/2,300);
  text(time,width/2,350);
  text("Time",width/2,400);
  text("You died "+deaths+" times",width/2,500);

  }

}
public void keyPressed()
{
  if(key==CODED)
  {
    if((keyCode==LEFT)&&(!dashing)){leftPressed=true;}
    if((keyCode==RIGHT)&&(!dashing)){rightPressed=true;}
    if((keyCode==UP)&&(!dashing)){upPressed=true;}
    if((keyCode==SHIFT)&&(!dashing)){shiftPressed=true;}
    
  }
  if(key==' '){spacePressed=true;}
}
public void keyReleased()
{
  if(key==CODED)
  {
    if(keyCode==LEFT){left=0; leftPressed=false;}
    if(keyCode==RIGHT){right=0; rightPressed=false;}
    if(keyCode==UP){upPressed=false;}
    if(keyCode==SHIFT){shiftPressed=false;}
  }   
  if(key==' '){spacePressed=false;}

}
class Ground
{
  float x;
  float y;
  float xwidth;
  float yheight;
  int groundcolor;
  Ground(float x, float y, float xwidth, float yheight, int black)
  {
    this.x=x;
    this.y=y;
    this.xwidth=xwidth;
    this.yheight=yheight;
    this.groundcolor=black;
  }
}

class Hazard
{
  float x;
  float y;
  float xwidth;
  float yheight;
  int hazardcolor;
  Hazard(float x, float y, float xwidth, float yheight, int red)
  {
    this.x=x;
    this.y=y;
    this.xwidth=xwidth;
    this.yheight=yheight;
    this.hazardcolor=red;
  }
}

class Goal
{
  float x;
  float y;
  float xwidth;
  float yheight;
  int goalcolor;
  Goal(float x, float y, float xwidth, float yheight, int red)
  {
    this.x=x;
    this.y=y;
    this.xwidth=xwidth;
    this.yheight=yheight;
    this.goalcolor=red;
  }
}

class Jump
{
  float x;
  float y;
  float xwidth;
  float yheight;
  int jumpcolor;
  Jump(float x, float y, float xwidth, float yheight, int cyan)
  {
    this.x=x;
    this.y=y;
    this.xwidth=xwidth;
    this.yheight=yheight;
    this.jumpcolor=cyan;
  }
}
  
//collision stops you from going in a block if you are touching it
public void groundCollision(float x,float y, float xwidth, float yheight, float x2, float y2, float x2width, float y2height)
{
  //this if statment decides wether or not it can check for ground and ceiling collision
  if(((x>x2)&&(x<x2+x2width))||((x+xwidth>x2)&&(x+xwidth<x2+x2width))||((x==x2)&&(x+xwidth==x2+x2width)))
  {
    if((y+yheight>y2)&&(y+yheight<y2+y2height)){groundCollide=true; jumpSpeed=0; gravity=0; playerY=y2-playerheight; jumping=false;hasDashed=false;}
    if((y<y2+y2height)&&(y>y2)){ceilingCollide=true; jumpSpeed=0; playerY=y2+playerheight;}
    if(y+yheight<=y2){overGround=true;}
  }
  //this if statment decides wether or not it can check for left and right collision
  else if(((y>y2)&&(y<y2+y2height))||((y+yheight>y2)&&(y+yheight<y2+y2height))||((y==y2)&&(y+yheight==y2+y2height)&&(y+yheight!=y2height)))
  {
    if((x+xwidth>=x2)&&(x+xwidth<=x2+x2width)){rightCollide=true;}
    if((x<=x2+x2width)&&(x>=x2)){leftCollide=true;} 
  }
else {rightCollide=false;leftCollide=false;groundCollide=false;ceilingCollide=false;overGround=false;}

 // println(rightCollide, leftCollide, groundCollide, ceilingCollide);
}
//if you touch the hazard block you will be reset to the start of the level
public void hazardCollision(float x,float y, float xwidth, float yheight, float x2, float y2, float x2width, float y2height)
{
  //this checks if it touches the red block
  if(((x>x2)&&(x<x2+x2width))||((x+xwidth>x2)&&(x+xwidth<x2+x2width))||((x==x2)&&(x+xwidth==x2+x2width)))
  {
    if((y+yheight>=y2)&&(y+yheight<=y2+y2height)){hazardTouch=true;}
    if((y<y2+y2height)&&(y>=y2)){hazardTouch=true;}
  }
  else if(((y>y2)&&(y<y2+y2height))||((y+yheight>y2)&&(y+yheight<y2+y2height))||((y==y2)&&(y+yheight==y2+y2height)&&(y+yheight!=y2height)))
  {
    if((x+xwidth>x2)&&(x+xwidth<x2+x2width)){hazardTouch=true;}
    if((x<x2+x2width)&&(x>x2)){hazardTouch=true;} 
  }

}
//if you touch the goal it takes you to the next level
public void goalCollision(float x,float y, float xwidth, float yheight, float x2, float y2, float x2width, float y2height)
{
  //this if statment decides wether or not it can check for ground and ceiling collision
  if(((x>x2)&&(x<x2+x2width))||((x+xwidth>x2)&&(x+xwidth<x2+x2width))||((x==x2)&&(x+xwidth==x2+x2width)))
  {
    if((y+yheight>y2)&&(y+yheight<y2+y2height)){goalTouch=true;}
    if((y<y2+y2height)&&(y>y2)){goalTouch=true;}
  }
  //this if statment decides wether or not it can check for left and right collision
  else if(((y>y2)&&(y<y2+y2height))||((y+yheight>y2)&&(y+yheight<y2+y2height))||((y==y2)&&(y+yheight==y2+y2height)&&(y+yheight!=y2height)))
  {
    if((x+xwidth>=x2)&&(x+xwidth<=x2+x2width)){goalTouch=true;}
    if((x<=x2+x2width)&&(x>=x2)){goalTouch=true;} 
  }
}

public void extraJumpCollision(float x,float y, float xwidth, float yheight, float x2, float y2, float x2width, float y2height)
{
  //this if statment decides wether or not it can check for ground and ceiling collision
  if(((x>x2)&&(x<x2+x2width))||((x+xwidth>x2)&&(x+xwidth<x2+x2width))||((x==x2)&&(x+xwidth==x2+x2width)))
  {
    if((y+yheight>y2)&&(y+yheight<y2+y2height)){jumpTouch=true;}
    if((y<y2+y2height)&&(y>y2)){jumpTouch=true;}
  }
  //this if statment decides wether or not it can check for left and right collision
  else if(((y>y2)&&(y<y2+y2height))||((y+yheight>y2)&&(y+yheight<y2+y2height))||((y==y2)&&(y+yheight==y2+y2height)&&(y+yheight!=y2height)))
  {
    if((x+xwidth>=x2)&&(x+xwidth<=x2+x2width)){jumpTouch=true;}
    if((x<=x2+x2width)&&(x>=x2)){jumpTouch=true;} 
  }
}
//draws the player
public void drawPlayer(float x,float y, float xwidth, float yheight)
{
 fill(magenta);
 drawSquare(x,y,xwidth,yheight);
}
//draws the hazard blocks
public void drawHazard(float v, float p)
{
  fill(hazard.hazardcolor);
  drawSquare(v,p,hazard.xwidth,hazard.yheight);
}
public void drawGround(float v, float p)
{
  fill(ground.groundcolor);
  drawSquare(v,p,ground.xwidth,ground.yheight);
}
public void drawGoal(float v, float p)
{
  fill(goal.goalcolor);
  drawSquare(v,p,goal.xwidth,goal.yheight);
}
public void drawExtraJump (float v, float p)
{
  fill(jump.jumpcolor);
  drawSquare(v,p,jump.xwidth,jump.yheight);
}
public void drawLevel()
{
 background(255);
 for(int i=0;i<groundtiles.size();i++)
 {
 Ground tile = groundtiles.get(i);
 drawGround(tile.x,tile.y);
 }
 for(int i=0;i<hazardtiles.size();i++)
 {
 Hazard tile = hazardtiles.get(i);
 drawHazard(tile.x,tile.y);
 }
 for(int i=0;i<jumptiles.size();i++)
 {
 Jump tile = jumptiles.get(i);
 drawExtraJump(tile.x,tile.y);
 }
 drawGoal(goal.x,goal.y);
leveltext();
//drawGrid();
}
public void drawSquare(float v, float p, float vwidth, float pheight)
{
  noStroke();
  rect(v,p,vwidth,pheight);
}
public void drawGrid()
{
  for(int i=0;i<1800;i+=50)
  {
    stroke(0);
    line(i,0,i,height);
  }
  for(int i=0; i<1000;i+=50)
  {
    stroke(0);
    line(0,i,width,i);
  }
}
public void leveltext()
{
  deathCounter();
  time();
  textFont(silkscreen,50);
  textAlign(CENTER);
  fill(0);
  text("Level "+levelnumber,width/2,50);
  
}
public void moveSquare()
{ 
  dash();
  if(rightPressed){right=playerSpeed;}
  if(leftPressed){left=playerSpeed;}
  if(rightCollide||(playerX+playerwidth>=width)){right=0;}
  if(leftCollide||(playerX<=0)){left=0;}
  if(!dashing){playerX+=(right-left);} 
  if(upPressed&&(!jumping)){jump();}
}
//makes you go up
public void jump()
{
  if((!jumping)) {jumpSpeed=jumpPower; gravity=realgravity; jumping=true;}
}
//when you press left or right then press shift you will move 250 pixels in the respective direction
public void dash()
{
  if(!hasDashed)
  {
    if((dashDistance<=dashLength))
    {
      if(leftPressed&&shiftPressed&&(!rightPressed)&&(!dashleft)&&(!groundCollide)){dashleft=true; dashing=true; playerY+=playerheight/4; playerheight/=2;}
      if(rightPressed&&shiftPressed&&(!leftPressed)&&(!dashright)&&(!groundCollide)){dashright=true; dashing=true; playerY+=playerheight/4; playerheight/=2;}
      if(dashing)
      {
      rightPressed=false;
      leftPressed=false;
      shiftPressed=false;
      upPressed=false;
      if(rightCollide||leftCollide){dashDistance+=dashSpeed; jumpSpeed=0;}
      else if(dashright){playerX+=dashSpeed; dashDistance+=dashSpeed; jumpSpeed=0;}
      else if(dashleft){playerX-=dashSpeed; dashDistance+=dashSpeed; jumpSpeed=0;}
      }
    }
    else
    {
     playerY-=playerheight/4;
     playerheight=squareSize;
     dashDistance=0;
     playerSpeed=realplayerSpeed;
     hasDashed=true;
     dashright=false;
     dashleft=false;
     dashing=false;
    }
  }

}
//gravity is the constant pulling down force
public void gravity()
//void gravity(float x, float xwidth, float x2, float x2width)
{
  playerY=playerY-jumpSpeed;
  jumpSpeed=jumpSpeed-gravity;
  if(ceilingCollide){jumpSpeed=0;playerY=groundY+playerheight;}
  if(!overGround){gravity=realgravity;}
}
public void playerReset()
{
  if(resetP){
    resetP=false;
    playerX=levelstartpos[0];
    playerY=levelstartpos[1];
    jumpSpeed=0;
    newlevel=true;
    playerY-=playerheight/4;
    playerheight=squareSize;
    dashDistance=0;
    playerSpeed=realplayerSpeed;
    hasDashed=false;
    dashright=false;
    dashleft=false;
    dashing=false;
    hazardTouch=false;
    println("resetP");
  }
  else if(hazardTouch){
    resetP=true;
    hazardTouch=false;
  }
  else if(goalTouch){
    newlevel=true;
    levelnumber++;
    goalTouch=false;
    playerY-=playerheight/4;
    playerheight=squareSize;
    dashDistance=0;
    playerSpeed=realplayerSpeed;
    hasDashed=false;
    dashright=false;
    dashleft=false;
    dashing=false;
  }
  else if((playerY+playerheight>height)||(playerX>width)||(playerX<(-playerwidth))){resetP=true;}
}
public void deathCounter()
{
  if (resetP){deaths++;}
  textFont(silkscreen,50);
  textAlign(CENTER);
  fill(0);
  text("Deaths: "+deaths,1600,50);
}
public void time()
{
  gametime=((int)(millis()-gameStarttime))/1000;
  if(((gametime%60)==0)&&(gametime>=60)){seconds="00";}else if(((gametime%60)<10)&&(gametime>=60)){seconds="0"+str(gametime%60);}else{seconds=str(gametime%60);}
  if((((gametime/60)%60)==0)&&(gametime>3600)){minutes="00:";}else if((((gametime/60)%60)<10)&&(gametime>=3600)){minutes="0"+str((gametime/60)%60)+":";}else if(gametime>=60){minutes=str((gametime/60)%60)+":";}else{minutes="";}
  if((gametime/3600)>0){hours=str(gametime/3600)+":";}else{hours="";}
  time = hours+minutes+seconds; 
  textFont(silkscreen,50);
  textAlign(CORNER);
  fill(0);
  text("Time: "+time,100,50);
}
public void drawTitle()
{
  background(255);
  if(titlepage==0)
  {
    textFont(silkscreen,100);
    textAlign(CENTER);
    fill(0);
    text("Box Adventures",width/2,200);
    textFont(silkscreen,50);
    text(flavor,width/2,300);
    text("Credits",200,height/2);
    text("Press Left",200,(height/2)+50);
    text("How To Play",1500,height/2);
    text("Press Right",1500,(height/2)+50);
    text("Press Space",width/2,900);
    text("To Play",width/2,950);
  }
  //credits
  if(titlepage==-1)
  {
    textFont(silkscreen,100);
    textAlign(CENTER);
    fill(0);
    text("Credits",width/2,70);
    textFont(silkscreen,50);
    text("Coded by Phillip",width/2,150);
    text("Art by Phillip",width/2,190);
    text("Flavor Text by Various People",width/2,230);
  }
  //howtoplay
  if(titlepage==1)
  {
    textFont(silkscreen,100);
    textAlign(CENTER);
    fill(0);
    text("How To Play",width/2,70);
    textFont(silkscreen,50);
    text("Left and Right keys to move",width/2,150);
    text("Up to Jump",width/2,190);
    text("Shift to Dash",width/2,230);
    text("You can only dash once in the air",width/2,270);
    

  }
}
public void randomFlavor()
{
  flavortext=loadStrings("Flavors.txt");
  flavor=flavortext[(int)random(flavortext.length)];
  println("There are "+flavortext.length+" strings in this array");
  for(int i=0;i<flavortext.length;i++){println(flavortext[i]);}
}
public void level(int l)
{
  newlevel=false;
  groundtiles.clear();
  hazardtiles.clear();
  jumptiles.clear();
  if(l==1) 
  {
  levelstartpos[0]=8*playerwidth;
  levelstartpos[1]=9*playerheight; 
  goal.x=27*goalwidth;
  goal.y=9*goalheight;
  for(int i=7;i<29;i++){groundtiles.add(new Ground(i*groundwidth,10*groundheight,groundwidth,groundheight,black));}
  }
  else if(l==2) 
  {
  levelstartpos[0]=8*playerwidth;
  levelstartpos[1]=9*playerheight; 
  goal.x=27*goalwidth;
  goal.y=9*goalheight;
  for(int i=7;i<29;i++){groundtiles.add(new Ground(i*groundwidth,10*groundheight,groundwidth,groundheight,black));}
  for(int i=8;i<10;i++){hazardtiles.add(new Hazard(18*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  }  
  else if(l==3)
  {
  levelstartpos[0]=16*playerwidth;
  levelstartpos[1]=18*playerheight; 
  goal.x=16*goalwidth;
  goal.y=3*goalheight;
  for(int i=6;i<19;i+=4){groundtiles.add(new Ground(14*groundwidth,i*groundheight,groundwidth,groundheight,black));}
  for(int i=8;i<19;i+=4){groundtiles.add(new Ground(18*groundwidth,i*groundheight,groundwidth,groundheight,black));}
  for(int i=0;i<36;i++){groundtiles.add(new Ground(i*groundwidth,19*groundheight,groundwidth,groundheight,black));}
  }
  else if(l==4)
  {
  levelstartpos[0]=2*playerwidth;
  levelstartpos[1]=2*playerheight; 
  goal.x=30*goalwidth;
  goal.y=18*goalheight;
  groundtiles.add(new Ground(2*groundwidth,3*groundheight,groundwidth,groundheight,black));
  }
  else if(l==5)
  {
  levelstartpos[0]=2*playerwidth;
  levelstartpos[1]=2*playerheight; 
  goal.x=2*goalwidth;
  goal.y=18*goalheight;
  for(int i=0;i<31;i++){groundtiles.add(new Ground(i*groundwidth,14*groundheight,groundwidth,groundheight,black));}
  for(int i=5;i<36;i++){groundtiles.add(new Ground(i*groundwidth,9*groundheight,groundwidth,groundheight,black));}
  for(int i=0;i<31;i++){groundtiles.add(new Ground(i*groundwidth,4*groundheight,groundwidth,groundheight,black));}
  for(int i=9;i<16;i++){hazardtiles.add(new Hazard(i*hazardwidth,10*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,13*hazardheight,hazardwidth,hazardheight,red));} 
  for(int i=20;i<27;i++){hazardtiles.add(new Hazard(i*hazardwidth,10*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,13*hazardheight,hazardwidth,hazardheight,red));} 
  for(int i=23;i<30;i++){hazardtiles.add(new Hazard(i*hazardwidth,8*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,7*hazardheight,hazardwidth,hazardheight,red));} 
  for(int i=9;i<16;i++){hazardtiles.add(new Hazard(i*hazardwidth,7*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,6*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,5*hazardheight,hazardwidth,hazardheight,red));} 
  for(int i=8;i<13;i++) {hazardtiles.add(new Hazard(i*hazardwidth,18*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,17*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,15*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=17;i<22;i++) {hazardtiles.add(new Hazard(i*hazardwidth,18*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,16*hazardheight,hazardwidth,hazardheight,red));hazardtiles.add(new Hazard(i*hazardwidth,15*hazardheight,hazardwidth,hazardheight,red));}  
  hazardtiles.add(new Hazard(10*hazardwidth,3*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(24*hazardwidth,3*hazardheight,hazardwidth,hazardheight,red));
  for(int i=0;i<36;i++){groundtiles.add(new Ground(i*groundwidth,19*groundheight,groundwidth,groundheight,black));}
  }
  else if(l==6)
  {
  levelstartpos[0]=16*playerwidth;
  levelstartpos[1]=18*playerheight; 
  goal.x=16*goalwidth;
  goal.y=3*goalheight;
  for(int i=10;i<26;i++){groundtiles.add(new Ground(i*groundwidth,19*groundheight,groundwidth,groundheight,black));}
  jumptiles.add(new Jump(18*jumpwidth,16*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(14*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(17*jumpwidth,10*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(15*jumpwidth,7*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(16*jumpwidth,5*jumpheight,jumpwidth,jumpheight,cyan));
  }
  else if(l==7)
  {
  levelstartpos[0]=1*playerwidth;
  levelstartpos[1]=2*playerheight; 
  goal.x=33*goalwidth;
  goal.y=17*goalheight;
  for(int i=0;i<4;i++){groundtiles.add(new Ground(i*groundwidth,3*groundheight,groundwidth,groundheight,black));}
  for(int i=3;i<11;i++){groundtiles.add(new Ground(i*groundwidth,18*groundheight,groundwidth,groundheight,black));}
  for(int i=4;i<18;i++){hazardtiles.add(new Hazard(3*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=0;i<16;i++){hazardtiles.add(new Hazard(6*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=25;i<29;i++){groundtiles.add(new Ground(i*groundwidth,3*groundheight,groundwidth,groundheight,black));}
  for(int i=28;i<36;i++){groundtiles.add(new Ground(i*groundwidth,18*groundheight,groundwidth,groundheight,black));}
  for(int i=4;i<18;i++){hazardtiles.add(new Hazard(28*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=0;i<16;i++){hazardtiles.add(new Hazard(31*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=21;i<28;i++){groundtiles.add(new Ground(i*groundwidth,16*groundheight,groundwidth,groundheight,black));}
  jumptiles.add(new Jump(10*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(11*jumpwidth,10*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(14*jumpwidth,7*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(18*jumpwidth,5*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(22*jumpwidth,4*jumpheight,jumpwidth,jumpheight,cyan));
  }
  else if(l==8)
  {
  levelstartpos[0]=14*playerwidth;
  levelstartpos[1]=8*playerheight; 
  goal.x=21*goalwidth;
  goal.y=8*goalheight;
  for(int i=11;i<25;i++){groundtiles.add(new Ground(i*groundwidth,9*groundheight,groundwidth,groundheight,black));}
  for(int i=0;i<9;i++){hazardtiles.add(new Hazard(17*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=0;i<9;i++){hazardtiles.add(new Hazard(18*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  jumptiles.add(new Jump(9*jumpwidth,14*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(18*jumpwidth,14*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(26*jumpwidth,14*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(29*jumpwidth,11*jumpheight,jumpwidth,jumpheight,cyan));
  }
  else if(l==9)
  {
  levelstartpos[0]=2*playerwidth;
  levelstartpos[1]=2*playerheight;
  goal.x=33*goalwidth;
  goal.y=2*goalheight;
  for(int i=0;i<5;i++){groundtiles.add(new Ground(i*groundwidth,3*groundheight,groundwidth,groundheight,black));}
  for(int i=31;i<36;i++){groundtiles.add(new Ground(i*groundwidth,3*groundheight,groundwidth,groundheight,black));}
  for(int i=4;i<19;i++){hazardtiles.add(new Hazard(4*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=0;i<17;i++){hazardtiles.add(new Hazard(7*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=4;i<17;i++){hazardtiles.add(new Hazard(i*hazardwidth,19*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=8;i<14;i++){hazardtiles.add(new Hazard(i*hazardwidth,16*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=7;i<19;i++){hazardtiles.add(new Hazard(16*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=0;i<7;i++){hazardtiles.add(new Hazard(27*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=20;i<31;i++){hazardtiles.add(new Hazard(i*hazardwidth,7*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=4;i<20;i++){hazardtiles.add(new Hazard(35*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int v=29;v<31;v++)
  {
  for(int i=8;i<16;i++){hazardtiles.add(new Hazard(v*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  }
  for(int i=17;i<26;i++){hazardtiles.add(new Hazard(i*hazardwidth,11*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=20;i<29;i++){hazardtiles.add(new Hazard(i*hazardwidth,15*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=17;i<35;i++){hazardtiles.add(new Hazard(i*hazardwidth,19*hazardheight,hazardwidth,hazardheight,red));}
  jumptiles.add(new Jump(14*jumpwidth,17*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(11*jumpwidth,15*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(8*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(15*jumpwidth,11*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(11*jumpwidth,9*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(27*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(18*jumpwidth,17*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(33*jumpwidth,17*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(33*jumpwidth,14*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(33*jumpwidth,11*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(33*jumpwidth,8*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(33*jumpwidth,5*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(29*jumpwidth,4*jumpheight,jumpwidth,jumpheight,cyan));
  }
  else if(l==10)
  {
  levelstartpos[0]=2*playerwidth;
  levelstartpos[1]=18*playerheight;
  goal.x=33*goalwidth;
  goal.y=2*goalheight;
  for(int i=9;i<14;i++){groundtiles.add(new Ground(i*groundwidth,9*groundheight,groundwidth,groundheight,black));}
  for(int i=0;i<5;i++){groundtiles.add(new Ground(i*groundwidth,19*groundheight,groundwidth,groundheight,black));}
  for(int i=17;i<20;i++){hazardtiles.add(new Hazard(8*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=13;i<15;i++){hazardtiles.add(new Hazard(8*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=9;i<11;i++){hazardtiles.add(new Hazard(8*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=5;i<8;i++){hazardtiles.add(new Hazard(8*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=15;i<17;i++){hazardtiles.add(new Hazard(i*hazardwidth,6*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=18;i<22;i++){hazardtiles.add(new Hazard(i*hazardwidth,6*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=8;i<20;i++){hazardtiles.add(new Hazard(21*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=15;i<20;i++){hazardtiles.add(new Hazard(24*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=4;i<14;i++){hazardtiles.add(new Hazard(24*hazardwidth,i*hazardheight,hazardwidth,hazardheight,red));}
  for(int i=17;i<24;i++){hazardtiles.add(new Hazard(i*hazardwidth,4*hazardheight,hazardwidth,hazardheight,red));}
  hazardtiles.add(new Hazard(3*hazardwidth,11*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(13*hazardwidth,15*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(26*hazardwidth,17*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(28*hazardwidth,16*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(30*hazardwidth,15*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(26*hazardwidth,13*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(29*hazardwidth,9*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(26*hazardwidth,8*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(28*hazardwidth,6*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(31*hazardwidth,6*hazardheight,hazardwidth,hazardheight,red));
  hazardtiles.add(new Hazard(28*hazardwidth,4*hazardheight,hazardwidth,hazardheight,red));
  jumptiles.add(new Jump(13*jumpwidth,17*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(17*jumpwidth,15*jumpheight,jumpwidth,jumpheight,cyan));  
  jumptiles.add(new Jump(13*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(3*jumpwidth,13*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(0*jumpwidth,11*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(3*jumpwidth,9*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(11*jumpwidth,6*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(17*jumpwidth,6*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(22*jumpwidth,17*jumpheight,jumpwidth,jumpheight,cyan));  
  jumptiles.add(new Jump(26*jumpwidth,16*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(28*jumpwidth,15*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(30*jumpwidth,14*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(26*jumpwidth,12*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(26*jumpwidth,9*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(29*jumpwidth,8*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(26*jumpwidth,7*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(28*jumpwidth,5*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(31*jumpwidth,5*jumpheight,jumpwidth,jumpheight,cyan));
  jumptiles.add(new Jump(28*jumpwidth,3*jumpheight,jumpwidth,jumpheight,cyan));
  }
  else
  {
  gameRunning=false;
  endScreen=true;
  }
  //if(l==11)
  //{ 
  //levelstartpos[0]=2*playerwidth;
  //levelstartpos[1]=18*playerheight;
  //goal.x=33*goalwidth;
  //goal.y=2*goalheight;
  //for(int i=0;i<5;i++){groundtiles.add(new Ground(i*groundwidth,19*groundheight,groundwidth,groundheight,black));}
  //hazardtiles.add(new Hazard(3*hazardwidth,11*hazardheight,hazardwidth,hazardheight,red));
  //}
}
  public void settings() {  size (1800,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Box_Adventures_100_dollar_DLC" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
